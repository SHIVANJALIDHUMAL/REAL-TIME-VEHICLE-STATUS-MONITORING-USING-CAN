indicator.o: INDICATOR.c
indicator.o: C:\KeilARM\ARM\INC\Philips\LPC21XX.h
indicator.o: delay.h
indicator.o: types.h
indicator.o: types.h
