typedef unsigned char u8;
typedef signed char s8;
typedef unsigned int u32;
typedef signed int s32;
typedef float f32;
typedef double d64;
typedef signed short int s16;
typedef unsigned short int u16;
