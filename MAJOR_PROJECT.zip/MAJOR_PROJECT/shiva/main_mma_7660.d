main_mma_7660.o: MAIN_MMA_7660.c
main_mma_7660.o: C:\KeilARM\ARM\INC\Philips\LPC21xx.h
main_mma_7660.o: delay.h
main_mma_7660.o: types.h
