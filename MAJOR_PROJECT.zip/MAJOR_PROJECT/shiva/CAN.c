#include<LPC21XX.h>
#include"types.h"
#include"delay.h"
#include"can_defines.h"
#include"can.h"

void can1_init(void)		 
{
	PINSEL1 |= (RD1_PIN_0_25);     

	C1MOD |= 1 << RM_BIT;         
	
	AFMR &= ~(1 << ACCOFF_BIT);    
	AFMR |= 1 << ACCBP_BIT;       

	C1BTR = BTR_LVAL;           

	C1MOD &= ~(1 << RM_BIT);	 
}

void can1_tx(CANF txF)
{
	u32 timeout = 50000;


	while(((C1GSR >> TBS1_BIT) & 1) == 0)
	{
		if(timeout-- == 0)        
			break;
	}

	C1TID1 = txF.ID;               


	C1TFI1 = ((txF.bfv.RTR << RTR_BIT) | (txF.bfv.DLC << DLC_BIT));

	if(txF.bfv.RTR != 1)           
	{
		C1TDA1 = txF.DATA1;        
		C1TDB1 = txF.DATA2;       
	}

	C1CMR |= ((1 << STB1_BIT) | (1 << TR_BIT));   

	timeout = 50000;

	
	while(((C1GSR >> TCS1_BIT) & 1) == 0)
	{
		if(timeout-- == 0)          
			break;
	}
}

u8 can1_rx(CANF *rxF)
{

	if(((C1GSR >> RBS_BIT) & 1) == 0)
	{
		return 0;                   
	}

	rxF->ID = C1RID;               

	rxF->bfv.RTR = ((C1RFS >> RTR_BIT) & 1);   
	
	rxF->bfv.DLC = ((C1RFS >> DLC_BIT) & 15); 
	
	
	if(rxF->bfv.RTR == 0)          
	{
		rxF->DATA1 = C1RDA;       
		rxF->DATA2 = C1RDB;       
	}

	C1CMR |= (1 << RRB_BIT);      

	return 1;                      
}

