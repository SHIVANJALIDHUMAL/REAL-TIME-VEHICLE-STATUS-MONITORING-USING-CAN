#include<LPC21XX.h>
#include"delay.h"
#include"can.h"
#include"can_defines.h"
#include"types.h"
#include"lcd.h"
#include"lcd_defines.h"
#include"indicator.h"

#define TX_LED 0


volatile u32 blink1 = 0,blink2 =0,eintflg1 = 0 , eintflg2 = 0;


void eint0_isr(void) __irq
{	
	eintflg1 = 1;          

	blink1 = !blink1;      
	blink2 = 0;            

	EXTINT = 1<<0;         
	VICVectAddr = 0;       
}



void eint2_isr(void) __irq
{
	eintflg2 = 1;         

	blink2 = !blink2;      
	blink1 = 0;           

	EXTINT = 1<<2;         
	VICVectAddr = 0;       
}


void ext_int_init(void)
{
	PINSEL0 |= EINT0_0_1|
	           EINT2_0_7;       
	  
	VICIntEnable = 1 << EINT0_VIC_CHNO|
	               1 << EINT2_VIC_CHNO;  

	VICVectCntl0 = (1 << 5)| EINT0_VIC_CHNO;   
	VICVectAddr0 = (s32) eint0_isr;           

	VICVectCntl1 =(1<<5) | EINT2_VIC_CHNO;     
	VICVectAddr1 = (s32) eint2_isr;            

	EXTMODE = 1 << 0|		
	          1 << 2;        
}
