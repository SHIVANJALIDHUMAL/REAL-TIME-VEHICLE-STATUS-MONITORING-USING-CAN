mma_7660.o: MMA_7660.c
mma_7660.o: C:\KeilARM\ARM\INC\Philips\LPC21xx.h
mma_7660.o: i2c.h
mma_7660.o: types.h
mma_7660.o: delay.h
mma_7660.o: types.h
