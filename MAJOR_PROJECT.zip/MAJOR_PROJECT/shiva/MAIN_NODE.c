#include<LPC21XX.h>
#include "delay.h"
#include "can.h"
#include "can_defines.h"
#include "types.h"
#include "lcd.h"
#include "lcd_defines.h"
#include "indicator.h"
#include "ds18b20.h"

#define TX_LED 0
u8 ind_stat=0;
//static u8 can_sync_timer=0;
CANF rxF;
CANF txF;
extern volatile u32 blink1 ,blink2,eintflg1,eintflg2;
char fuel,tp, tpd, blocks,i;
int temp=0;

int main()
{

   static u32 can_sync_timer=0;
	
	IODIR0 |= TX_LED;

    can1_init();        
    ext_int_init();     
    lcd_init();         

    WriteToCGRAM();     
  
	while(1)
	{
		lcd_cmd(GOTO_LINE_1_POS_0);
		lcd_str("   <AUTO MONITOR>   ");  

		lcd_cmd(GOTO_LINE_2_POS_0);
		lcd_str("TEMP:");               

    	 temp=ReadTemp();
/*		 tp=(temp)>>7;
		 tpd=temp&0x08 ? 0x35:0x30;

		 lcd_int(tp);
		 lcd_char('.');
		 lcd_char(tpd);	*/


		lcd_int(temp);
		lcd_char(0xdf);
	 	lcd_str("C");

		lcd_cmd(0xD4);
		lcd_str("INDICATOR:");          

		lcd_cmd(0x94);
		lcd_str("FUEL: "); 
		      
		
		if(eintflg1 == 1)                
		{
			eintflg1 = 0;
		                 
			left();         
		}
		else if(eintflg2 == 1)        
		{
			eintflg2 = 0;
			right();                      
		}
		
		if(can1_rx(&rxF))               
		{
			if(rxF.ID == 2)               
			{
				
				fuel = rxF.DATA2;       
				
				if(fuel > 100)            
				{
					fuel=100;
				}

				lcd_cmd(0x94);
				lcd_str("FUEL: ");
				
				blocks=fuel/25;           
				
				for(i=0;i<4;i++)         
				{
					if(i<blocks)
					{
						lcd_char(i+3);    
					}
					else
					{
						lcd_char(' ');    
					}
				}
				
				lcd_int(fuel);           
				lcd_char('%');
				lcd_char(' ');

				can_sync_timer++;

				if(can_sync_timer>=2)
				{
				    can_sync_timer=0;
	                //IODIR0 |= 1 << TX_LED;     
	
                	txF.ID = 1;                
                	txF.bfv.RTR = 0;           
	                txF.DATA1 = ind_stat;        
	                txF.bfv.DLC = 1;           

	                can1_tx(txF);              
                    //	IOPIN0 ^= 1 << TX_LED;     
                }       

				 
			}
		}
				
	    delay_ms(200);                    


		if(blink1)                       
		{
			lcd_cmd(0xDe);
			lcd_char(' ');
  		          			
			delay_ms(500);

			lcd_cmd(0xDe);
			lcd_char(1);          
		}
		else
		{
			lcd_cmd(0xDe);
			lcd_char(1);                 
		}

		lcd_cmd(0xE0);
		lcd_char(2);                      

		if(blink2)                        
		{					
			lcd_cmd(0xE2);
			lcd_char(' ');
  		          			
			delay_ms(500);

			lcd_cmd(0xE2);
			lcd_char(0);  
		}
		else
		{
			lcd_cmd(0xE2);
			lcd_char(0);                  
		}
	}
}
 
void left(void)
{
    ind_stat=1;
	IODIR0 |= 1 << TX_LED;     
	
	txF.ID = 1;                
	txF.bfv.RTR = 0;           
	txF.DATA1 = ind_stat;        
	txF.bfv.DLC = 1;           

	can1_tx(txF);              
	IOPIN0 ^= 1 << TX_LED;     
}

void right(void)
{
     ind_stat=2;
	IODIR0 |= 1 << TX_LED;

	txF.ID = 1;              
	txF.bfv.RTR = 0;
	txF.DATA1 = ind_stat;          
	txF.bfv.DLC = 1;

	can1_tx(txF);         
	IOPIN0 ^= 1 << TX_LED;
}
