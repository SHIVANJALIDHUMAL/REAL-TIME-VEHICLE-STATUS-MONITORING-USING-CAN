#include<LPC21xx.h>

#include "delay.h"


#define D 1<<22		 //1-WIRE DATA LINE

#define R (IOPIN0&(1<<22))




/**RESET FUNCTION DEFINATION FOR DS18B20**/

unsigned char ResetDS18b20(void)

{

	unsigned int  presence; 

    IODIR0 |= D;

	IOPIN0 |= D;	

	delay_us(1); //////////////1Us

	IOPIN0 &= ~(D);

	delay_us(478);//////////////486Us 

	IOPIN0 |= D;

	delay_us(54); //////////////55Us

	presence = IOPIN0 ; 	

	delay_us(423);//////////////431Us

	

	if(presence&R)

		return 1;

	else 

		return 0;

}


/**READING A BIT USING 1-WIRE PROTOCOL FROM DS18B20**/

unsigned char ReadBit(void)

{

	unsigned int B;	

	IOPIN0 &= ~(D);

	delay_us(1);//////////////1Us

	IOPIN0 |= D;

	IODIR0 &= ~(D);

	delay_us(10);//////////////11Us

	B=IOPIN0;

	IODIR0 |=D;

	if(B&R)

		return 1;

	else 

		return 0;

}

/**WRITING A BIT USING 1-WIRE PROTOCOL INTO DS18B20**/

void WriteBit(unsigned char Dbit)

{

	IOPIN0 &= ~(D);

	delay_us(1);//////////////1Us

	if(Dbit)

		IOPIN0 |= D;

	delay_us(58);//////////////59Us

	IOPIN0 |= D;

	delay_us(1);

}

/**READING A BYTE USING 1-WIRE PROTOCOL FROM DS18B20**/

unsigned char ReadByte(void)

{

	unsigned char i;

	unsigned char Din = 0;

	for (i=0;i<8;i++)

	{

		Din|=ReadBit()? 0x01<<i:Din;

		delay_us(45); //////////////46Us

	}

	return(Din);

}


/**WRITING A BIT USING 1-WIRE PROTOCOL INTO DS18B20**/

void WriteByte(unsigned char Dout)

{

	unsigned char i;

	for (i=0; i<8; i++)

	{	    

		WriteBit((Dout & 0x1)); 

		Dout = Dout >> 1;

		delay_us(1);

	}

	delay_us(98);//////////////100Us

}


/**READING TEMPERATURE FROM DS18B20 USING 1-WIRE PROTOCOL**/

int ReadTemp(void)

{

	unsigned char n,buff[2];

	int temp;

	ResetDS18b20();	  //RESET DS18B20

    WriteByte(0xcc);   // skip ROM

    WriteByte(0x44);   // perform temperature conversion

    while (ReadByte()==0); // wait for conversion complete	

	ResetDS18b20();

	WriteByte(0xcc);   // skip ROM

	WriteByte(0xbe);    // read the result

    for (n=0; n<2; n++) // read 9 bytes but, use only one byte

    {

       buff[n]=ReadByte();  // read DS1820

    }

	temp=buff[1];

	temp=temp<<8;

	//temp=temp|buff[0];

	temp|=buff[0];
	temp=temp/16;

	return(temp);

}
