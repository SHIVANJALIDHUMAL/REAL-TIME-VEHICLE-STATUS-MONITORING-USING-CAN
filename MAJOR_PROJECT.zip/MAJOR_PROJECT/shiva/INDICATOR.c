#include<LPC21XX.h>
#include"delay.h"
#include"types.h"

#define LED_START 0
#define INDICATOR 0xFF << LED_START      

static s32 position = 0;                

s32 i;

void led_left_step(void)
{
	IODIR0 |= 0xFF << LED_START;        		

    IOSET0 = INDICATOR;                
    IOCLR0 = 1 << (LED_START + position);   

    position++;                        
    if(position >= 8)
        position = 0;                   

    delay_ms(100);                      
}

void led_right_step(void)
{
	IODIR0 |= 0xFF << LED_START;       	

    IOSET0 = INDICATOR;                
    IOCLR0 = 1 << (LED_START + position);   

    position--;                         
    if(position < 0)
        position = 7;                 

    delay_ms(100);                      
}

void led_off(void)
{
    IOSET0 = INDICATOR;                
}
