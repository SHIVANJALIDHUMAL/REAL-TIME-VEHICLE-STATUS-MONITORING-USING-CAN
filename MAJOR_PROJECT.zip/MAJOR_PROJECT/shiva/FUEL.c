#include<LPC21xx.h>
#include"typeS.h"
#include"delay.h"
#include"fuel_defnes.h"

void adc_init(void)
{
	PINSEL1 &=~(0xff << 22);
	PINSEL1 |= (AIN0_0_27)|
			   (AIN1_0_28);
			   

 ADCR |= (CLK_DIV << CLK_DIV_BITS)|
 		 (1 << PDN_BIT);
}

void read_adc_value(u32 ch_no ,u32 *dVal ,f32 *eAr)
{
	ADCR &= 0xffffff00; 

	ADCR |= (1 << ch_no)| 
			(1 << CONV_START_BITS);	 

	delay_us(3);				

	while(((ADDR >> DONE_BIT) & 1) == 0);

	ADCR &=~ (1 << CONV_START_BITS);  
	
	*dVal = ((ADDR >> RESULT_BITS) & 1023);	
	
	*eAr = (*dVal * (3.3/1023));		
}
