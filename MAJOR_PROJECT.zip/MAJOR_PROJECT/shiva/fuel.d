fuel.o: FUEL.c
fuel.o: C:\KeilARM\ARM\INC\Philips\LPC21xx.h
fuel.o: typeS.h
fuel.o: delay.h
fuel.o: types.h
fuel.o: fuel_defnes.h
